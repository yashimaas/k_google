CamemBERT
----------------------------------------------------

``CamembertConfig``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertConfig
    :members:


``CamembertTokenizer``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertTokenizer
    :members:


``CamembertModel``
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertModel
    :members:


``CamembertForMaskedLM``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertForMaskedLM
    :members:


``CamembertForSequenceClassification``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertForSequenceClassification
    :members:


``CamembertForMultipleChoice``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertForMultipleChoice
    :members:


``CamembertForTokenClassification``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.CamembertForTokenClassification
    :members:
