ALBERT
----------------------------------------------------

``AlbrtConfig``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertConfig
    :members:


``AlbertTokenizer``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertTokenizer
    :members:


``AlbertModel``
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertModel
    :members:


``AlbertForMaskedLM``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertForMaskedLM
    :members:


``AlbertForSequenceClassification``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertForSequenceClassification
    :members:


``AlbertForQuestionAnswering``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.AlbertForQuestionAnswering
    :members:


``TFAlbertModel``
~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TFAlbertModel
    :members:


``TFAlbertForMaskedLM``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TFAlbertForMaskedLM
    :members:


``TFAlbertForSequenceClassification``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TFAlbertForSequenceClassification
    :members:
